function link_to(link) {
  location.href = link;
};
