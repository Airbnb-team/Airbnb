$(function(){
	$('.room-show-overview').click(function(){
		$('.room-explanatory-area').show();
	});
	$('.room-show-overview-hidden').click(function(){
		$('.room-explanatory-area').hide();
	});
});

$(function(){
	$('.room-show-amenity-display').click(function(){
		$('.room-amenity-area').show();
	});
	$('.room-show-amenity-hidden').click(function(){
		$('.room-amenity-area').hide();
	});
});

$(function(){
	$('.listing-amenity-display').click(function(){
		$('.room-amenity-area').show();
	});
	$('.listing-amenity-hidden').click(function(){
		$('.room-amenity-area').hide();
	});
});
